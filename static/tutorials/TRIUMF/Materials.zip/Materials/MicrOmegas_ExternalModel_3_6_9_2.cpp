//   GAMBIT: Global and Modular BSM Inference Tool
//   *********************************************
///  \file
///
///  Frontend for MicrOmegas SingletDM 3.6.9.2 backend
///
///  *********************************************
///
///  Authors (add name and date if you modify):
///
/// \author Jonathan Cornell
/// \date April 2017
///
///  *********************************************

#include "gambit/Backends/frontend_macros.hpp"
#include "gambit/Backends/frontends/MicrOmegas_ExternalModel_3_6_9_2.hpp"
#include <unistd.h>

// Convenience functions (definitions)
BE_NAMESPACE
{
    double dNdE(double Ecm, double E, int inP, int outN)
    {
      // outN 0-5: gamma, e+, p-, nu_e, nu_mu, nu_tau
      // inP:  0 - 6: glu, d, u, s, c, b, t
      //       7 - 9: e, m, l
      //       10 - 15: Z, ZT, ZL, W, WT, WL
      double tab[250];  // NZ = 250
      // readSpectra() moved to initialization function.
      // Must be inside critical block if used here!
      // readSpectra();
      mInterp(Ecm/2, inP, outN, tab);
      return zInterp(log(E/Ecm*2), tab);
    }
}
END_BE_NAMESPACE

// Initialisation function (definition)
BE_INI_FUNCTION
{
     int error;
     char cdmName[10];

     int VZdecayOpt, VWdecayOpt; // 0=no 3 body final states
                                 // 1=3 body final states in annihlations
                                 // 2=3 body final states in co-annihilations
     VZdecayOpt = runOptions->getValueOrDef<int>(1, "VZdecay");
     VWdecayOpt = runOptions->getValueOrDef<int>(1, "VWdecay");
     *VZdecay = VZdecayOpt;
     *VWdecay = VWdecayOpt;


     // Uncomment below to force MicrOmegas to do calculations in unitary gauge
     // *ForceUG=1;

     // Get model parameters:
     double Muv = *Param["Muv"];
     double Mp1 = *Param["Mp1"];
     double lam1 = *Param["lam1"];

     // Test that phi_1 is really stable
     if (Mp1 > Muv)
     {
         std::stringstream msg;
         msg << "DM is unstable.";
         invalid_point().raise(msg.str());
     }

     // Pass masses and couplings to MicrOmegas
     error = assignVal((char*) "Muv", Muv);
     if (error != 0) backend_error().raise(LOCAL_INFO, "Unable to set Muv in "
             "MicrOmegas. MicrOmegas error code: " + std::to_string(error));

     error = assignVal((char*) "Mp1", Mp1);
     if (error != 0) backend_error().raise(LOCAL_INFO, "Unable to set Mp1 in "
             "MicrOmegas. MicrOmegas error code: " + std::to_string(error));

     error = assignVal((char*) "lam1", lam1);
     if (error != 0) backend_error().raise(LOCAL_INFO, "Unable to set lam1 in "
              "MicrOmegas. MicrOmegas error code: " + std::to_string(error));

     // Initialise micrOMEGAs mass spectrum
     error = sortOddParticles(byVal(cdmName));
     if (error != 0) backend_error().raise(LOCAL_INFO, "MicrOmegas function "
             "sortOddParticles returned error code: " + std::to_string(error));

}
END_BE_INI_FUNCTION
