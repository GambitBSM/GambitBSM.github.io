//  GAMBIT: Global and Modular BSM Inference Tool
//  *********************************************
//
//  External Model for tutorial
//
//  *********************************************
//
//  Authors
//  =======
//
//  Your Name Here
//
//
//  *********************************************

#ifndef __ExternalModel_hpp__
#define __ExternalModel_hpp__

#define MODEL ExternalModel
  START_MODEL
  DEFINEPARS(Mp1, Muv, lam1)
#undef MODEL

#endif
